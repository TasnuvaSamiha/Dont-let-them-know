print("Hi there, I will help you decode the information\U0001F60E")
txt = (input("\U0001F338 Enter you text and decode:"))

rversd_txt = txt[::-1]
print("Coded text :",rversd_txt)

