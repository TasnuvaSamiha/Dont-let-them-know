print("Hi there, I will help you share information without letting people easily know it!\U0001F60E")
txt = (input("\U0001F338 Enter you text and turn it into a code:"))

rversd_txt = txt[::-1]
print("Coded text :",rversd_txt)

